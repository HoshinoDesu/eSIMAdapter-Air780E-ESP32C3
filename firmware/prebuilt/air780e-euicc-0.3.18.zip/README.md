# 0.3.18 固件

适用于 CORE-ESP32C3（4 MiB Flash）+ AIR780E，刷写目标为 ESP32-C3。

包内脚本可直接刷入。首次启动连接热点 `Air780E-xxxxxx`（无需密码），打开 `http://192.168.4.1/`，填写 2.4 GHz Wi-Fi 和面板访问密钥。

断电拆开叠插，只接 C3 USB。在解压目录执行，COM22 改为实际端口：

```powershell
python -m esptool --chip esp32c3 --port COM22 --baud 460800 --before default_reset --after hard_reset write_flash 0x0 bootloader.bin 0x8000 partition-table.bin 0x10000 luatos.bin 0x390000 script.bin
```

只更新脚本：

```powershell
python -m esptool --chip esp32c3 --port COM22 --baud 460800 --before default_reset --after hard_reset write_flash 0x390000 script.bin
```

刷完断电重新叠插，仅接 AIR780E USB。刷写保留设备上已有设置。

| 文件 | 偏移 |
| --- | --- |
| bootloader.bin | 0x0 |
| partition-table.bin | 0x8000 |
| luatos.bin | 0x10000 |
| script.bin | 0x390000 |

文件校验值见 `manifest.json`，底层源码和补丁见仓库 `firmware/`。
