# 0.3.11 固件

适用于 CORE-ESP32C3（4 MiB Flash）+ AIR780E，刷写目标为 ESP32-C3。

包内脚本使用空配置。首次使用按仓库 `c3/README.md` 填写 Wi-Fi 和访问密钥，编译后替换 `script.bin`。

断电拆开叠插，只接 C3 USB。在解压目录执行，COM22 改为实际端口：

```powershell
python -m esptool --chip esp32c3 --port COM22 --baud 460800 --before default_reset --after hard_reset write_flash 0x0 bootloader.bin 0x8000 partition-table.bin 0x10000 luatos.bin 0x390000 script.bin
```

只更新脚本：

```powershell
python -m esptool --chip esp32c3 --port COM22 --baud 460800 --before default_reset --after hard_reset write_flash 0x390000 script.bin
```

刷完断电重新叠插，仅接 AIR780E USB。刷写保留设备上已有设置。

| 文件 | 偏移 |
| --- | --- |
| bootloader.bin | 0x0 |
| partition-table.bin | 0x8000 |
| luatos.bin | 0x10000 |
| script.bin | 0x390000 |

文件校验值见 `manifest.json`，底层源码和补丁见仓库 `firmware/`。
